#!/bin/bash

# Start your portfolio (already in your script)
echo "Starting Portfolio..."
cd rpi-portfolio || exit 1
npm run dev &

# Wait for the local server to boot
sleep 5

# Start Tunnelmole and extract the link
echo "Starting Tunnelmole..."
TM_OUTPUT=$(tmole --port 3000 2>&1 | tee /tmp/tunnelmole.log &)

# Wait for Tunnelmole to initialize
sleep 8

# Extract the first valid tmole.dev URL from log
LIVE_URL=$(grep -m 1 -Eo 'https://[a-zA-Z0-9.-]+\.tmole\.dev' /tmp/tunnelmole.log)

# Check if URL was found
if [[ -z "$LIVE_URL" ]]; then
  echo "❌ Tunnelmole URL not found."
  exit 1
fi

echo "✅ Tunnelmole live URL: $LIVE_URL"

# Push to GitHub Gist
# Replace these with your actual values
GIST_ID="543f8d84ff1b2a982207ba372b78db9a"
GITHUB_TOKEN="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"

# Update the Gist file content
curl -X PATCH "https://api.github.com/gists/$GIST_ID" \
  -H "Authorization: token $GITHUB_TOKEN" \
  -H "Content-Type: application/json" \
  -d @- <<EOF
{
  "files": {
    "current-url.txt": {
      "content": "$LIVE_URL"
    }
  }
}
EOF

echo "✅ Gist updated: $LIVE_URL"
