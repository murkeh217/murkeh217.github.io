#!/bin/bash

echo "🚀 Starting portfolio..."
cd ~/rpi-portfolio || exit

# Kill existing node and tmole processes (optional cleanup)
pkill -f "npm run dev"
pkill -f "tmole"

# Start the dev server
echo "Starting dev server..."
npm run dev > /dev/null 2>&1 &

# Start Tunnelmole
echo "Starting Tunnelmole..."
tmole 3000 > /tmp/tunnelmole.log 2>&1 &
sleep 2

# Show log content for debug
echo "🔍 Dumping /tmp/tunnelmole.log"
cat /tmp/tunnelmole.log

# Wait for the public URL
echo "⏳ Waiting for Tunnelmole to give URL..."

TUNNEL_URL=""
for i in {1..30}; do
  TUNNEL_URL=$(grep -oE "https://[a-zA-Z0-9.-]+\.tunnelmole\.net" /tmp/tunnelmole.log | head -n 1)
  echo "[$i] TUNNEL_URL=$TUNNEL_URL"
  if [[ ! -z "$TUNNEL_URL" ]]; then
    break
  fi
  sleep 1
done

if [[ -z "$TUNNEL_URL" ]]; then
  echo "❌ Tunnelmole URL not found in 30s."
  exit 1
fi

echo "✅ Tunnelmole URL: $TUNNEL_URL"

# Dummy upload step
echo "🔁 Would upload to Gist here"

# Push to GitHub Gist
# Replace these with your actual values
GIST_ID="543f8d84ff1b2a982207ba372b78db9a"
GITHUB_TOKEN="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"

# Update the Gist file content
curl -X PATCH "https://api.github.com/gists/$GIST_ID" \
  -H "Authorization: token $GITHUB_TOKEN" \
  -H "Content-Type: application/json" \
  -d @- <<EOF
{
  "files": {
    "current-url.txt": {
      "content": "$TUNNEL_URL"
    }
  }
}
EOF

echo "✅ Gist updated: $TUNNEL_URL"
