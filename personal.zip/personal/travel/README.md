# A gallery of squiggle images!

A Pen created on CodePen.

Original URL: [https://codepen.io/t_afif/pen/BabwVLx](https://codepen.io/t_afif/pen/BabwVLx).

Based on: https://codepen.io/t_afif/pen/qBvXXBe