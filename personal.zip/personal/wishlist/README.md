# CSS vertical carousel animation

A Pen created on CodePen.

Original URL: [https://codepen.io/aija/pen/xvXWoK](https://codepen.io/aija/pen/xvXWoK).

Infinitely rotating vertical carousel animation. CSS only.