# Rhombus image gallery

A Pen created on CodePen.

Original URL: [https://codepen.io/t_afif/pen/KKowpYz](https://codepen.io/t_afif/pen/KKowpYz).

CSS Tip!
https://twitter.com/ChallengesCss/status/1542463825479450627