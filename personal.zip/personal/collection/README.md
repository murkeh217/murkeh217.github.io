# 🧪 corner-shape hexagon avatars

A Pen created on CodePen.

Original URL: [https://codepen.io/cbolson/pen/ogjWyyg](https://codepen.io/cbolson/pen/ogjWyyg).

