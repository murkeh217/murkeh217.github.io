# CSS Only image gallery

A Pen created on CodePen.

Original URL: [https://codepen.io/t_afif/pen/abGvYVX](https://codepen.io/t_afif/pen/abGvYVX).

CSS Tip!
https://twitter.com/ChallengesCss/status/1567475934197866496