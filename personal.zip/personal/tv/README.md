# 3D Carousel rotating

A Pen created on CodePen.

Original URL: [https://codepen.io/claudiulazar/pen/OdvVOo](https://codepen.io/claudiulazar/pen/OdvVOo).

3D Carousel which rotates