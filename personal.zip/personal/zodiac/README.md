# Rounded grid of images

A Pen created on CodePen.

Original URL: [https://codepen.io/t_afif/pen/xxWXbXz](https://codepen.io/t_afif/pen/xxWXbXz).

CSS Tip!
https://twitter.com/ChallengesCss/status/1551934547549454341