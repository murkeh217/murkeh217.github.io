# CSS Grid for Multi-Sized Avatars

A Pen created on CodePen.

Original URL: [https://codepen.io/jlengstorf/pen/emNmxXV](https://codepen.io/jlengstorf/pen/emNmxXV).

