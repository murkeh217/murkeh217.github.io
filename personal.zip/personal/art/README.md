# CSS grid with expandable images

A Pen created on CodePen.

Original URL: [https://codepen.io/t_afif/pen/MWVyaMe](https://codepen.io/t_afif/pen/MWVyaMe).

CSS Tip!
https://twitter.com/ChallengesCss/status/1545367863250264075