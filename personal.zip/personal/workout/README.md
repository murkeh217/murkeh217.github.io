# CPC Challenge - Slide In / Slide Out - Slide Inwards(?)

A Pen created on CodePen.

Original URL: [https://codepen.io/yexx/pen/PwqMvjB](https://codepen.io/yexx/pen/PwqMvjB).

Group of images that the details slides in and out on hover using clip-path, and the image itself slide inwards