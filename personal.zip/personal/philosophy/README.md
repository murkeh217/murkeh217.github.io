# Expand image #scss #flexbox

A Pen created on CodePen.

Original URL: [https://codepen.io/kristen17/pen/wvPebxy](https://codepen.io/kristen17/pen/wvPebxy).

