# :has() Sibling Gallery

A Pen created on CodePen.

Original URL: [https://codepen.io/jh3y/pen/xxjxqOL](https://codepen.io/jh3y/pen/xxjxqOL).

