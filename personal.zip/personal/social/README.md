# Attract hover effect

A Pen created on CodePen.

Original URL: [https://codepen.io/Mamboleoo/pen/XgBvrJ](https://codepen.io/Mamboleoo/pen/XgBvrJ).

I saw the hover effect on the links of this [page](http://www.climber.io/) and I wanted to reproduce them :)