# swiperjs infinite looping tab working on IE 11

A Pen created on CodePen.

Original URL: [https://codepen.io/Innodel/pen/poRdBaG](https://codepen.io/Innodel/pen/poRdBaG).

